package com.qyzmode.service;

import com.qyzmode.prjo.Blog;

import java.util.List;
import java.util.Map;

public interface ArchivesService {


    Map<String, List<Blog>>  archives();
}
